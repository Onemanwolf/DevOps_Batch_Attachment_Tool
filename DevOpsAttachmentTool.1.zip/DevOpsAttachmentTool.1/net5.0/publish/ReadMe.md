﻿# Markdown File

Command with three arguments 

- path to files  
	- Example: ..\\Files\\AttachmentHRTest
- Url for DevOps Orginization 
	- Example:  https://carnivalcruiselines.visualstudio.com
- personalAccessToken



App.exe path url personAccessToken

DevOpsClientApiApp.exe ..\\Files\\AttachmentHRTest  https://carnivalcruiselines.visualstudio.com 