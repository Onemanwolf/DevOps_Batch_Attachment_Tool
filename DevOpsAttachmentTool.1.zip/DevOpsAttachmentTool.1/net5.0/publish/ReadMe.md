﻿# Markdown File

Command with three arguments 

- path to files  
	- Example: ..\\Files\\AttachmentHRTest
- Url for DevOps Orginization 
	- Example:  https://carnivalcruiselines.visualstudio.com
- personalAccessToken
	- ywi2rgo6uf2v3l5g6pc2zmhwowob6fx36stiun3n4d74536lggpq


App.exe path url personAccessToken

DevOpsClientApiApp.exe ..\\Files\\AttachmentHRTest  https://carnivalcruiselines.visualstudio.com ywi2rgo6uf2v3l5g6pc2zmhwowob6fx36stiun3n4d74536lggpq